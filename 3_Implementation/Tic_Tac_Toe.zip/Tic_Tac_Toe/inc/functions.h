#ifndef FUNCTION_DOT_H   
#define FUNCTION_DOT_H

#include<stdio.h>
#include<stdlib.h>


int checkwin(char*);
void board(char*);
int main();
#endif